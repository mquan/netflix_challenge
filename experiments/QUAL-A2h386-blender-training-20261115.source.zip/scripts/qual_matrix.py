"""Verified block access to qualifying matrices and one-column overlays."""
import json
from pathlib import Path
import numpy as np
from streaming_blend import digest,design


class InsertedColumn:
    def __init__(self,base,column,index):
        self.base,self.column,self.index=base,column,index
        self.shape=(len(base),base.shape[1]+1)

    def __len__(self):return self.shape[0]

    def __getitem__(self,rows):
        b=self.base[rows];v=self.column[rows];n=self.index
        if b.ndim==1:return np.r_[b[:n],v,b[n:]].astype(np.float32)
        out=np.empty((len(b),self.shape[1]),dtype=np.float32,order='F')
        out[:,:n]=b[:,:n];out[:,n]=v;out[:,n+1:]=b[:,n:]
        return out


def verified_matrix(prefix,report):
    if report.get('matrix_layout')!='column_insertion':
        if digest(prefix+'.x.npy')!=report['x_sha256']:raise ValueError('qualifying matrix changed')
        return np.load(prefix+'.x.npy',mmap_mode='r')
    path=prefix+'.matrix.json'
    if digest(path)!=report['composite_spec_sha256']:raise ValueError('matrix specification changed')
    s=json.loads(Path(path).read_text())
    if digest(s['base_path'])!=s['base_sha256'] or digest(s['column_path'])!=s['column_sha256']:
        raise ValueError('overlay input changed')
    base=np.load(s['base_path'],mmap_mode='r');column=np.fromfile(s['column_path'],dtype='<f4')
    if len(column)!=len(base) or not np.isfinite(column).all() or not 0<=s['insert_at']<=base.shape[1]:
        raise ValueError('invalid column overlay')
    result=InsertedColumn(base,column,s['insert_at'])
    if list(result.shape)!=s['shape']:raise ValueError('overlay shape changed')
    return result


def predict_matrix_ridge(raw,context,columns,weights):
    result=np.empty(len(raw))
    for lo in range(0,len(raw),8192):
        hi=min(lo+8192,len(raw))
        result[lo:hi]=3.6+design(raw[lo:hi][:,:columns],context[lo:hi])@weights
    return result
