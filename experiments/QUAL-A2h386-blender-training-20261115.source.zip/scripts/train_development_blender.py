#!/usr/bin/env python3
"""Fit/freeze blender models using development inputs only; infer queries later.

This separates training from slow base-model qualifying exports. A models_ready
report is deliberately not an auditable qualifying prediction report.
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
import numpy as np
import torch
from fit_qual_blend import solve,nn_features
from gbdt_blend import load,blend_fold
from streaming_blend import digest,predict_ridge
from streaming_nn_blend import standardized,train_device


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--bank',required=True);ap.add_argument('--features',required=True)
    ap.add_argument('--output',required=True);ap.add_argument('--device',choices=['cpu','mps'],default='cpu')
    ap.add_argument('--threads',type=int,default=2)
    ap.add_argument('--seeds',nargs='+',type=int,default=[2026,7,13])
    a=ap.parse_args();root=Path(a.output);root.mkdir(parents=True,exist_ok=False)
    torch.set_num_threads(a.threads)
    b=json.loads(Path(a.bank+'.inputs.json').read_text())
    if b['config'].get('sample_weights'):raise ValueError('this fixed recipe requires an unweighted development bank')
    if digest(b['config']['data'])!=b['data_sha256'] or digest(b['config']['meta'])!=b['meta_sha256']:
        raise ValueError('development inputs changed')
    d=load(b['config']['data']);y=d['probe']['rating'].astype(np.float64);users=d['probe']['user'].copy();del d
    if not np.all((y>=1)&(y<=5)):raise ValueError('development ratings required')
    raw=np.load(a.bank+'.x.npy',mmap_mode='r');c=np.load(b['config']['meta'])['context']
    inner=blend_fold(users.astype(np.uint64)*np.uint64(7)+np.uint64(1))==0
    stats_file=np.load(a.bank+'.stats.npz');stats=tuple(stats_file[k] for k in ('gram','rhs','count'))
    report=dict(state='starting',config=vars(a),bank_sha256=digest(a.bank+'.inputs.json'),
                stats_sha256=digest(a.bank+'.stats.npz'),development_rows=len(y),
                blend_rule='Fixed equal average of seed-averaged tree and NN2 residuals',
                qualifying_inputs_provided=False,qualifying_labels_read=False,
                torch_version=torch.__version__,numpy_version=np.__version__)
    start=time.monotonic()

    def status(state,**values):
        report.update(state=state,elapsed_seconds=time.monotonic()-start,**values)
        temp=root/'report.tmp';temp.write_text(json.dumps(report,indent=2)+'\n');temp.replace(root/'report.json')
        print(json.dumps(dict(state=state,**values)),flush=True)

    status('ridge')
    full=solve(stats,np.ones(10,dtype=bool));iw=solve(stats,np.arange(10)%2==0)
    np.savez(root/'ridge-weights.npz',full=full,inner=iw)
    base=predict_ridge(raw[:,:b['columns']],c,full);ib=predict_ridge(raw[:,:b['columns']],c,iw)
    np.save(root/'development-base.npy',base,allow_pickle=False)
    np.save(root/'development-inner-base.npy',ib,allow_pickle=False)
    del stats,stats_file
    plan=dict(bank=a.bank,output=str(root),seeds=a.seeds,threads=a.threads)
    (root/'tree-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    status('tree_worker')
    subprocess.run([sys.executable,str(Path(__file__).with_name('train_tree_models.py')),
                    '--plan',str(root/'tree-plan.json')],check=True)
    tree=json.loads((root/'tree-report.json').read_text())
    if tree['state']!='complete' or tree['torch_loaded']:raise ValueError('invalid isolated tree training')
    status('normalization',tree_rounds=tree['tree_rounds'])
    features=np.load(a.features,mmap_mode='r')
    rows=np.linspace(0,len(raw)-1,min(256,len(raw)),dtype=int)
    if features.shape!=(len(raw),raw.shape[1]+1) or not np.array_equal(
            features[rows],nn_features(np.array(raw[rows],dtype=np.float32,order='F'),b['columns'])):
        raise ValueError('cached NN encodings differ')
    report['nn_features_sha256']=digest(a.features)
    normal,scaler=standardized(features,np.ones(len(y),dtype=bool),
                              output=str(root/'nn-normalized.npy'),return_scaler=True)
    np.savez(root/'nn-scaler.npz',**scaler)
    # Full CPU refits gather many random rows: retain a contiguous matrix once.
    training=np.ascontiguousarray(normal) if a.device=='cpu' else normal
    cfg=SimpleNamespace(hidden=128,layers=2,dropout=.2,lr=.0003,weight_decay=.01,
                        batch=4096,patience=5,device=a.device,resident_features=a.device=='mps')
    epochs_used=[]
    for seed in a.seeds:
        _,epochs=train_device(training[~inner],y[~inner]-ib[~inner],cfg,seed,60,
                              valid=(training[inner],y[inner]-ib[inner]))
        status('nn_refit',seed=seed,epochs=epochs)
        model,_=train_device(training,y-base,cfg,seed,epochs)
        torch.save(dict(state=model.state_dict(),config=vars(cfg),seed=seed,epochs=epochs),root/f'nn-{seed}.pt')
        epochs_used.append(epochs);del model
        status('nn_seed_complete',seed=seed,nn_epochs=epochs_used)
    hashes={p.name:digest(p) for p in root.iterdir() if p.suffix in ('.pt','.npz','.txt')}
    status('models_ready',outputs=hashes,nn_epochs=epochs_used)


if __name__=='__main__':main()
