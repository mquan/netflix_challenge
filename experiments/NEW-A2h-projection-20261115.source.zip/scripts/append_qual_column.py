#!/usr/bin/env python3
"""Attach a verified full-training local base to an audited qualifying bank."""
import argparse
import json
import os
from pathlib import Path
import numpy as np
from streaming_blend import digest


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base-bank',required=True);ap.add_argument('--base-qual',required=True)
    ap.add_argument('--bank',required=True);ap.add_argument('--local-report',required=True)
    ap.add_argument('--local-column',required=True);ap.add_argument('--dataset-manifest',required=True)
    ap.add_argument('--output',required=True)
    a=ap.parse_args()
    base=json.loads(Path(a.base_bank+'.inputs.json').read_text())
    bank=json.loads(Path(a.bank+'.inputs.json').read_text())
    q=json.loads(Path(a.base_qual+'.json').read_text())
    local=json.loads(Path(a.local_report).read_text())
    if local['state']!='complete' or local['metric'] is not None:
        raise ValueError('local base has not completed label-isolated production training')
    if local['dataset_manifest_sha256']!=digest(a.dataset_manifest):raise ValueError('local query dataset differs')
    if local['predictions_sha256']!=digest(a.local_column):raise ValueError('local prediction changed')
    if local['checkpoint_sha256']!=digest(Path(a.local_column).with_suffix('.pt')):
        raise ValueError('local checkpoint changed')
    if q['qualifying_labels_read'] is not False or q['bank_sha256']!=digest(a.base_bank+'.inputs.json'):
        raise ValueError('unverified qualifying bank')
    if q['dataset_manifest_sha256']!=local['dataset_manifest_sha256'] or q['data_sha256']!=local['data_sha256']:
        raise ValueError('different qualifying row order/data')
    n=base['columns']
    if bank['columns']!=n+1 or bank['names'][:n]+bank['names'][n+1:]!=base['names']:
        raise ValueError('bank differs by more than one trailing base')
    if bank['inputs'][bank['names'][n]]!=local['column_sha256']:
        raise ValueError('local production recipe does not match the retained development base')
    for key in ('data_sha256','meta_sha256','extra_meta_names'):
        if bank[key]!=base[key]:raise ValueError('development schema differs: '+key)
    for name in base['names']:
        if bank['inputs'][name]!=base['inputs'][name]:raise ValueError('development column changed')
    for suffix,key in [('.x.npy','x_sha256'),('.context.npy','context_sha256')]:
        if digest(a.base_qual+suffix)!=q[key]:raise ValueError('qualifying features changed')
    raw=np.load(a.base_qual+'.x.npy',mmap_mode='r')
    values=np.fromfile(a.local_column,dtype='<f4')
    if len(values)!=len(raw) or len(values)!=local['prediction_count'] or not np.isfinite(values).all():
        raise ValueError('local prediction rows differ')
    if Path(a.output+'.json').exists() or Path(a.output+'.x.npy').exists():raise ValueError('output exists')
    Path(a.output).parent.mkdir(parents=True,exist_ok=True)
    x=np.lib.format.open_memmap(a.output+'.x.npy',mode='w+',dtype='<f4',
                               shape=(len(raw),raw.shape[1]+1),fortran_order=True)
    x[:,:n]=raw[:,:n];x[:,n]=values;x[:,n+1:]=raw[:,n:];x.flush()
    os.link(a.base_qual+'.context.npy',a.output+'.context.npy')
    q.update(columns=bank['columns'],width=x.shape[1],bank_sha256=digest(a.bank+'.inputs.json'),
             parent_qual_manifest_sha256=digest(a.base_qual+'.json'),
             local_production_report_sha256=digest(a.local_report),
             local_execution_overrides=local.get('execution_overrides'),
             local_prediction_sha256=local['predictions_sha256'],
             x_sha256=digest(a.output+'.x.npy'),qualifying_labels_read=False,
             derivation='Insert retained local base at the exact development column; same verified query dataset/order')
    q['qualifying_inputs'][a.local_column]=local['predictions_sha256']
    Path(a.output+'.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps(dict(state='complete',output=a.output,rows=len(raw),columns=bank['columns'])),flush=True)


if __name__=='__main__': main()
