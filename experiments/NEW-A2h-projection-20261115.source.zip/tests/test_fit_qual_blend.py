"""Production fitting must be independent of qualifying feature values."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
sys.path.insert(0,str(ROOT/'tests'))
from test_joint import dataset
from gbdt_blend import load,blend_fold
from streaming_blend import digest,grouped_statistics
from fit_qual_blend import nn_features


class FinalFitTests(unittest.TestCase):
    def test_qualifying_changes_do_not_change_fitted_models_or_stopping(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);data=root/'dev.bin';dataset(data,correlated_train=True)
            d=load(data);y=d['probe']['rating'].astype('f8');users=d['probe']['user']
            rng=np.random.default_rng(12)
            p=(y[:,None]+rng.normal(0,.3,(len(y),2))).astype('f4')
            raw=np.column_stack([p,rng.normal(size=(len(y),3))]).astype('f4')
            c=np.column_stack([np.ones(len(y)),rng.normal(size=(len(y),4))]).astype('f4')
            meta=root/'meta.npz';np.savez(meta,context=c)
            bank=str(root/'bank')
            np.save(bank+'.x.npy',raw)
            groups=blend_fold(users)*2+(blend_fold(users.astype('u8')*np.uint64(7)+np.uint64(1))==0)
            gram,rhs,count=grouped_statistics(p,c,y,groups,chunks=16)
            np.savez(bank+'.stats.npz',gram=gram,rhs=rhs,count=count)
            record=dict(config=dict(data=str(data),meta=str(meta),metric_label='Synthetic fixture'),
                        data_sha256=digest(data),meta_sha256=digest(meta),columns=2)
            Path(bank+'.inputs.json').write_text(json.dumps(record))
            reports=[];models=[];trees=[];scalers=[]
            for variant in range(2):
                qual=str(root/f'qual{variant}')
                qr=rng.normal(3+variant,1,(23,5)).astype('f4')
                qc=np.column_stack([np.ones(23),rng.normal(size=(23,4))]).astype('f4')
                np.save(qual+'.x.npy',qr);np.save(qual+'.context.npy',qc)
                q=dict(state='complete',qualifying_labels_read=False,rows=23,
                       bank_sha256=digest(bank+'.inputs.json'),x_sha256=digest(qual+'.x.npy'),
                       context_sha256=digest(qual+'.context.npy'))
                Path(qual+'.json').write_text(json.dumps(q))
                output=root/f'run{variant}'
                result=subprocess.run([sys.executable,str(ROOT/'scripts/fit_qual_blend.py'),
                    '--bank',bank,'--qual',qual,'--output',str(output),'--device','cpu','--threads','1',
                    '--tree-seeds','2026','--nn-seeds','2026'],capture_output=True,text=True,cwd=ROOT)
                self.assertEqual(result.returncode,0,result.stdout+result.stderr)
                r=json.loads((output/'report.json').read_text());self.assertEqual(r['state'],'complete')
                self.assertFalse(r['qualifying_labels_read']);self.assertIsNone(r['metric'])
                self.assertEqual(len(np.fromfile(output/'qualifying-final.f32','<f4')),23)
                reports.append(r);models.append(torch.load(output/'nn-2026.pt',map_location='cpu',weights_only=True)['state'])
                trees.append((output/'tree-2026.txt').read_text())
                scalers.append(dict(np.load(output/'nn-scaler.npz')))
            self.assertEqual(reports[0]['tree_rounds'],reports[1]['tree_rounds'])
            self.assertEqual(reports[0]['nn_epochs'],reports[1]['nn_epochs'])
            self.assertEqual(trees[0],trees[1])
            for key in models[0]: self.assertTrue(torch.equal(models[0][key],models[1][key]),key)
            for key in scalers[0]: np.testing.assert_array_equal(scalers[0][key],scalers[1][key])
            # Decoupled training receives no qualifying inputs and must match
            # the already-tested fit, including its selected stopping budget.
            features=root/'features.npy';np.save(features,nn_features(raw,2))
            training=root/'training-only'
            result=subprocess.run([sys.executable,str(ROOT/'scripts/train_development_blender.py'),
                '--bank',bank,'--features',str(features),'--output',str(training),'--device','cpu',
                '--threads','1'],capture_output=True,text=True,cwd=ROOT)
            self.assertEqual(result.returncode,0,result.stdout+result.stderr)
            r=json.loads((training/'report.json').read_text())
            self.assertEqual(r['state'],'models_ready')
            self.assertFalse(r['qualifying_inputs_provided'])
            self.assertFalse((training/'qualifying-final.f32').exists())
            self.assertEqual(r['nn_epochs'][0],reports[0]['nn_epochs'][0])
            self.assertEqual((training/'tree-2026.txt').read_text(),trees[0])
            model=torch.load(training/'nn-2026.pt',map_location='cpu',weights_only=True)['state']
            for key in model:self.assertTrue(torch.equal(model[key],models[0][key]),key)


if __name__=='__main__': unittest.main()
