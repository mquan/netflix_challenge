import sys
import tempfile
from pathlib import Path
import unittest
from types import SimpleNamespace
import numpy as np
import torch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from streaming_nn_blend import standardized, train_device, predict_device
from round8_nn_blend import standardize


class NormalizationTests(unittest.TestCase):
    def test_memory_and_disk_scaling_match_original(self):
        rng=np.random.default_rng(3)
        x=rng.normal(size=(1000,37)); x[:,0]=1
        fit=np.arange(1000)%5!=0
        expected=standardize(x,fit)
        np.testing.assert_array_equal(standardized(x,fit,block=7),expected)
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'norm.npy'
            actual=standardized(np.asfortranarray(x),fit,block=7,output=p)
            np.testing.assert_array_equal(actual,expected)
            np.testing.assert_array_equal(np.load(p),expected)

    @unittest.skipUnless(torch.backends.mps.is_available(),'MPS unavailable')
    def test_mps_numeric_agreement_without_dropout(self):
        rng=np.random.default_rng(8)
        x=rng.normal(size=(128,9)).astype('f4'); y=rng.normal(size=128)
        a=SimpleNamespace(hidden=16,layers=2,dropout=0.,lr=.0003,weight_decay=.01,
                          batch=64,patience=5,device='cpu')
        cpu,_=train_device(x,y,a,12,2)
        a.device='mps'
        gpu,_=train_device(x,y,a,12,2)
        np.testing.assert_allclose(predict_device(gpu,x,'mps'),predict_device(cpu,x,'cpu'),atol=2e-5)


if __name__=='__main__': unittest.main()
