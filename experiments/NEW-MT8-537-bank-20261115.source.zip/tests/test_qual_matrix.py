import json
from pathlib import Path
import sys
import tempfile
import unittest
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'scripts'))
from qual_matrix import verified_matrix,predict_matrix_ridge
from streaming_blend import digest,predict_ridge


class QualMatrixTests(unittest.TestCase):
    def test_overlay_matches_physical_matrix_and_rejects_changed_inputs(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);base=np.arange(30,dtype='f4').reshape(6,5);column=np.arange(6,dtype='f4')+.5
            np.save(root/'base.npy',base);column.tofile(root/'extra.f32');prefix=str(root/'qual')
            spec=dict(base_path=str(root/'base.npy'),base_sha256=digest(root/'base.npy'),
                      column_path=str(root/'extra.f32'),column_sha256=digest(root/'extra.f32'),
                      insert_at=3,shape=[6,6])
            Path(prefix+'.matrix.json').write_text(json.dumps(spec))
            report=dict(matrix_layout='column_insertion',composite_spec_sha256=digest(prefix+'.matrix.json'))
            overlay=verified_matrix(prefix,report);physical=np.column_stack([base[:,:3],column,base[:,3:]])
            for rows in [slice(None),slice(1,4),np.array([4,0,2]),3]:
                np.testing.assert_array_equal(overlay[rows],physical[rows])
            context=np.ones((6,2));w=np.arange(10)*.01
            np.testing.assert_allclose(predict_matrix_ridge(overlay,context,4,w),predict_ridge(physical[:,:4],context,w))
            np.save(root/'base.npy',base+1)
            with self.assertRaisesRegex(ValueError,'changed'):verified_matrix(prefix,report)


if __name__=='__main__':unittest.main()
