"""Probe-aligned movie-metadata tree features from LLM-generated title tags (movie_tags.tsv)."""
import csv, sys, collections
import numpy as np
sys.path.insert(0, 'scripts')
from gbdt_blend import load

tags = list(csv.DictReader(open(sys.argv[1]), delimiter='\t'))
assert len(tags) == 17770 and all(int(t['movie_id']) == i + 1 for i, t in enumerate(tags))
kinds = sorted({t['kind'] for t in tags}); aud = ['kids', 'family', 'teen', 'adult', 'mature']
tone = {'light': 0, 'neutral': 1, 'dark': 2}; conf = {'low': 0, 'medium': 1, 'high': 2}
fr_size = collections.Counter(t['franchise'] for t in tags if t['franchise'])
main_genres = ['action', 'comedy', 'drama', 'horror', 'romance', 'scifi', 'family', 'thriller', 'documentary', 'foreign']
table = {
    'kind': [kinds.index(t['kind']) for t in tags],
    'audience': [aud.index(t['audience']) for t in tags],
    'tone': [tone[t['tone']] for t in tags],
    'popularity': [int(t['era_popularity']) for t in tags],
    'confidence': [conf[t['confidence']] for t in tags],
    'franchise_size': [fr_size.get(t['franchise'], 0) for t in tags],
}
for g in main_genres:
    table['g_' + g] = [float(g in t['genres'].split('|')) for t in tags]
d = load('data/processed/netflix.bin'); items = d['probe']['item'].astype(np.int64) - 1
for name, values in table.items():
    np.asarray(values, dtype='<f4')[items].tofile(f'artifacts/r8/meta-{name}.f32')
print(len(items), 'probe rows;', len(table), 'columns:', ' '.join(table))
