#!/usr/bin/env python3
"""Export a predeclared snapshot average from a shared fixed-budget fit prefix.

Each component is a completed, hashed epoch checkpoint. Training may continue
beyond the final component; this exporter never fits or scores query labels.
"""
import argparse
import dataclasses
import json
from pathlib import Path
import time
from production_neural import digest,find_recipe,load_trainer,validate_dataset


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--producer',required=True);ap.add_argument('--reference',required=True)
    ap.add_argument('--dataset-manifest',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--registry',default='experiments/QUAL-A2h-registry.json')
    ap.add_argument('--device',choices=['cpu','mps'],default='mps');ap.add_argument('--threads',type=int,default=1)
    a=ap.parse_args();start=time.monotonic();producer=Path(a.producer)
    reference=json.loads(Path(a.reference).read_text());epochs=reference['epochs']
    if reference['kind']!='snapshot_reference' or reference['weights']!='equal':raise ValueError('invalid reference')
    if digest(reference['path'])!=reference['column_sha256']:raise ValueError('development reference changed')
    source=json.loads((producer/'report.json').read_text())
    registry=json.loads(Path(a.registry).read_text());recipe=find_recipe(registry,Path(source['column']).name)
    if source['column_sha256']!=reference['parent_retained_column_sha256'] or source['column_sha256']!=recipe['column_sha256']:
        raise ValueError('different base-model family')
    if reference['data_sha256']!=recipe['original_data_sha256']:raise ValueError('development split differs')
    data,manifest=validate_dataset(a.dataset_manifest)
    if source['dataset_manifest_sha256']!=digest(a.dataset_manifest) or source['data_sha256']!=manifest['outputs'][data.name]:
        raise ValueError('production query order differs')
    captures=json.loads((producer/'snapshots/report.json').read_text())['snapshots']
    selected=[]
    for epoch in epochs:
        entry=captures[str(epoch)]
        if digest(entry['path'])!=entry['sha256']:raise ValueError('captured checkpoint changed')
        selected.append(entry)
    history=json.loads((producer/'model.progress.json').read_text())['records']
    if len(history)<max(epochs):raise ValueError('training prefix incomplete')
    trainer=load_trainer(recipe,producer/'source');trainer.torch.set_num_threads(a.threads)
    import numpy as np
    d=trainer.load(data)
    if not np.all(d['probe']['rating']==0):raise ValueError('query labels must be unknown sentinels')
    root=Path(a.output);root.mkdir(parents=True,exist_ok=False)
    result=np.zeros(len(d['probe']));states=[];config=None
    for epoch,entry in zip(epochs,selected):
        saved=trainer.torch.load(entry['path'],map_location='cpu',weights_only=True)
        if saved['epoch']!=epoch or saved['config']!=source['config']:raise ValueError('snapshot identity differs')
        c=trainer.Config(**saved['config']);c=dataclasses.replace(c,device=a.device)
        model=trainer.SequenceModel(saved['items'],c,saved['weeks']).to(a.device)
        model.load_state_dict(saved['state']);pred=trainer.predict(model,d)
        if pred.shape!=result.shape or not np.isfinite(pred).all():raise ValueError('invalid component prediction')
        result+=pred.astype(np.float64)/len(epochs)
        pred.astype('<f4').tofile(root/f'e{epoch}.f32')
        states.append(saved);config=saved['config'];del model,pred
        if a.device=='mps':trainer.torch.mps.empty_cache()
        print(json.dumps(dict(state='component_complete',epoch=epoch)),flush=True)
    result.astype('<f4').tofile(root/'model.f32')
    trainer.torch.save(dict(kind='snapshot_prediction_mean',epochs=epochs,states=states,
                           data_sha256=source['data_sha256']),root/'model.pt')
    report=dict(state='complete',kind='snapshot_ensemble',column=reference['path'],
                column_sha256=reference['column_sha256'],metric=None,training_requested=True,
                fixed_epochs=max(epochs),records=history[:max(epochs)],snapshot_epochs=epochs,
                training_budget_note='Completed shared prefix of fixed12-epoch producer; no extra fitting in exporter',
                dataset_manifest_sha256=digest(a.dataset_manifest),data_sha256=source['data_sha256'],
                predictions_sha256=digest(root/'model.f32'),checkpoint_sha256=digest(root/'model.pt'),
                prediction_count=len(result),prediction_min=float(result.min()),prediction_max=float(result.max()),
                config=config,execution_overrides=source.get('execution_overrides'),sources=source['sources'],
                reference_sha256=digest(a.reference),source_snapshots=selected,
                qualifying_labels_read=False,elapsed_seconds=time.monotonic()-start)
    (root/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)


if __name__=='__main__':main()
